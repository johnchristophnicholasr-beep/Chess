package com.chess.app;

import android.Manifest;import android.app.*;import android.os.*;import android.content.*;import android.content.pm.PackageManager;import android.speech.*;import org.json.JSONObject;import android.speech.tts.TextToSpeech;import android.webkit.*;import java.util.*;

public class MainActivity extends Activity {
 WebView web; SpeechRecognizer sr; TextToSpeech tts;
 @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"AndroidVoice"); web.loadUrl("file:///android_asset/index.html"); tts=new TextToSpeech(this, st->{});}
 void startVoice(){ if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},44);return;} if(sr!=null)sr.destroy(); sr=SpeechRecognizer.createSpeechRecognizer(this); sr.setRecognitionListener(new RecognitionListener(){public void onReadyForSpeech(Bundle p){}public void onBeginningOfSpeech(){}public void onRmsChanged(float r){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){}public void onError(int e){send("Voice error. Try again.");}public void onResults(Bundle x){ArrayList<String> a=x.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty())send(a.get(0));}public void onPartialResults(Bundle x){}public void onEvent(int a,Bundle b){}}); Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Say a chess move");sr.startListening(i);}
 void send(String text){String q=JSONObject.quote(text);runOnUiThread(()->web.evaluateJavascript("window.voiceResult("+q+")",null));}
 void speak(String text){if(tts!=null)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"chess");}
 class Bridge{ @JavascriptInterface public void listen(){startVoice();} @JavascriptInterface public void say(String s){speak(s);} }
 @Override protected void onDestroy(){if(sr!=null)sr.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
}
