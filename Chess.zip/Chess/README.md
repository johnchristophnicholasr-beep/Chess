# Chess
A phone-friendly Android WebView chess prototype with AI mode buttons, multiplayer/custom lobby UI, room codes, team selection, global/lobby/team chat UI, profiles, XP, achievements, rankings, statistics, beginner tutorial Lv.1-10, and native realistic TTS/voice recognition.

## Build on GitHub
1. Upload this project to a GitHub repository.
2. Open Actions → Build Chess APK → Run workflow.
3. Download the `Chess-debug-apk` artifact.

Note: real online matchmaking/chat and true chess AI require a backend/engine; this starter APK contains the UI/prototype flows and native voice bridge.
