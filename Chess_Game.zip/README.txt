CHESS starter ZIP

Features:
- Loading screen
- Name: Chess
- Easy, Normal, Hard and Impossible AI
- Local two-player Human mode
- XP + level-ups
- Restart/menu
- Ad placeholder

For the real AI, add Stockfish 18 lite single-threaded:
stockfish/stockfish-18-lite-single.js
stockfish/stockfish-18-lite-single.wasm

Stockfish.js is GPLv3. See the Stockfish.js project/license before distributing.

Online real-human matchmaking is not included yet; Human mode is two players on one device.
