# Chess

A simple offline Android chess game.

Build:
- GitHub Actions -> Build Chess APK
- Open the successful run
- Artifacts -> Chess-APK
- Download the APK artifact

This first version is offline and uses a simple built-in computer opponent. Online human multiplayer and real ad services require backend/account configuration.
