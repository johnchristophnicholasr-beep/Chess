package com.example.chess;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new ChessView(this));
    }
}

class ChessView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final char[][] board = new char[8][8];
    private int selectedR=-1, selectedC=-1;
    private boolean whiteTurn=true, gameOver=false;
    private int level=1;
    private final Random rng=new Random();

    ChessView(Context c) { super(c); reset(); p.setTypeface(Typeface.create("sans", Typeface.NORMAL)); }

    void reset() {
        String[] rows={"rnbqkbnr","pppppppp","........","........","........","........","PPPPPPPP","RNBQKBNR"};
        for(int r=0;r<8;r++) board[r]=rows[r].toCharArray();
        selectedR=selectedC=-1; whiteTurn=true; gameOver=false;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w=getWidth(), h=getHeight();
        c.drawColor(Color.rgb(18,20,25));
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE);
        p.setTextSize(Math.min(w, h)*0.065f);
        c.drawText("CHESS", w/2f, 48, p);
        p.setTextSize(16);
        c.drawText(gameOver ? "Game over — tap New Game" : (whiteTurn ? "Your turn" : "Computer thinking..."),
                w/2f, 76, p);

        float top=92, size=Math.min(w, h-145)/8f, left=(w-size*8)/2f;
        p.setTextSize(size*0.72f);
        for(int r=0;r<8;r++) for(int col=0;col<8;col++){
            p.setColor(((r+col)%2==0)?Color.rgb(238,238,210):Color.rgb(118,150,86));
            c.drawRect(left+col*size, top+r*size, left+(col+1)*size, top+(r+1)*size,p);
            if(r==selectedR && col==selectedC){
                p.setColor(Color.argb(150,80,130,255));
                c.drawRect(left+col*size, top+r*size, left+(col+1)*size, top+(r+1)*size,p);
            }
            char pc=board[r][col];
            if(pc!='.'){
                p.setColor(Character.isUpperCase(pc)?Color.WHITE:Color.BLACK);
                p.setStyle(Paint.Style.FILL);
                c.drawText(piece(pc), left+(col+.5f)*size, top+(r+.76f)*size,p);
                p.setStyle(Paint.Style.FILL);
            }
        }

        p.setColor(Color.rgb(35,39,48));
        c.drawRoundRect(w/2f-150, top+size*8+18, w/2f+150, top+size*8+65, 18,18,p);
        p.setColor(Color.WHITE); p.setTextSize(17);
        c.drawText("New Game   •   Level "+level, w/2f, top+size*8+48,p);
    }

    String piece(char x){
        switch(Character.toLowerCase(x)){
            case 'k': return "♚"; case 'q': return "♛"; case 'r': return "♜";
            case 'b': return "♝"; case 'n': return "♞"; default: return "♟";
        }
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float w=getWidth(), h=getHeight(), size=Math.min(w,h-145)/8f, left=(w-size*8)/2f, top=92;
        if(e.getY()>top+size*8+10){ reset(); return true; }
        if(gameOver || !whiteTurn) return true;
        int c=(int)((e.getX()-left)/size), r=(int)((e.getY()-top)/size);
        if(r<0||r>7||c<0||c>7) return true;

        if(selectedR<0){
            if(Character.isUpperCase(board[r][c])){selectedR=r;selectedC=c;invalidate();}
        } else {
            if(r==selectedR&&c==selectedC){selectedR=selectedC=-1;invalidate();return true;}
            if(isLegal(selectedR,selectedC,r,c)){
                board[r][c]=board[selectedR][selectedC]; board[selectedR][selectedC]='.';
                if(Character.toLowerCase(board[r][c])=='k' && r==0) gameOver=true;
                whiteTurn=false; selectedR=selectedC=-1; invalidate();
                if(!gameOver) postDelayed(()->computerMove(), 250);
            } else {
                if(Character.isUpperCase(board[r][c])) {selectedR=r;selectedC=c;invalidate();}
            }
        }
        return true;
    }

    boolean isLegal(int sr,int sc,int tr,int tc){
        char pc=board[sr][sc], target=board[tr][tc];
        if(pc=='.'||!Character.isUpperCase(pc)||Character.isUpperCase(target)) return false;
        int dr=tr-sr, dc=tc-sc, adr=Math.abs(dr), adc=Math.abs(dc);
        switch(Character.toLowerCase(pc)){
            case 'p':
                if(dc==0 && target=='.' && dr==-1) return true;
                if(dc==0 && target=='.' && sr==6 && dr==-2 && board[5][sc]=='.') return true;
                return adc==1 && dr==-1 && target!='.' && Character.isLowerCase(target);
            case 'n': return (adr==2&&adc==1)||(adr==1&&adc==2);
            case 'k': return adr<=1&&adc<=1;
            case 'b': return adr==adc && clear(sr,sc,tr,tc);
            case 'r': return (dr==0||dc==0) && clear(sr,sc,tr,tc);
            case 'q': return ((dr==0||dc==0)||(adr==adc)) && clear(sr,sc,tr,tc);
        }
        return false;
    }

    boolean clear(int sr,int sc,int tr,int tc){
        int rr=Integer.signum(tr-sr), cc=Integer.signum(tc-sc);
        int r=sr+rr,c=sc+cc;
        while(r!=tr||c!=tc){if(board[r][c]!='.')return false;r+=rr;c+=cc;}
        return true;
    }

    void computerMove(){
        if(gameOver)return;
        ArrayList<int[]> moves=new ArrayList<>();
        for(int r=0;r<8;r++)for(int c=0;c<8;c++){
            if(Character.isLowerCase(board[r][c])) for(int tr=0;tr<8;tr++)for(int tc=0;tc<8;tc++)
                if(isBlackLegal(r,c,tr,tc)) moves.add(new int[]{r,c,tr,tc});
        }
        if(moves.isEmpty()){gameOver=true;invalidate();return;}
        int[] best=moves.get(rng.nextInt(moves.size()));
        int bestScore=-1;
        for(int[] m:moves){
            char t=board[m[2]][m[3]];
            int score=(t=='.'?0:pieceValue(t));
            if(level>=2) score+=rng.nextInt(3);
            if(level>=3 && score>bestScore){bestScore=score;best=m;}
        }
        board[best[2]][best[3]]=board[best[0]][best[1]];
        board[best[0]][best[1]]='.';
        if(Character.toLowerCase(board[best[2]][best[3]])=='k' && best[2]==7) gameOver=true;
        whiteTurn=true; invalidate();
    }

    boolean isBlackLegal(int sr,int sc,int tr,int tc){
        char pc=board[sr][sc], target=board[tr][tc];
        if(pc=='.'||!Character.isLowerCase(pc)||Character.isLowerCase(target))return false;
        int dr=tr-sr,dc=tc-sc,adr=Math.abs(dr),adc=Math.abs(dc);
        switch(Character.toLowerCase(pc)){
            case 'p':
                if(dc==0&&target=='.'&&dr==1)return true;
                if(dc==0&&target=='.'&&sr==1&&dr==2&&board[2][sc]=='.')return true;
                return adc==1&&dr==1&&target!='.'&&Character.isUpperCase(target);
            case 'n':return(adr==2&&adc==1)||(adr==1&&adc==2);
            case 'k':return adr<=1&&adc<=1;
            case 'b':return adr==adc&&clear(sr,sc,tr,tc);
            case 'r':return(dr==0||dc==0)&&clear(sr,sc,tr,tc);
            case 'q':return((dr==0||dc==0)||(adr==adc))&&clear(sr,sc,tr,tc);
        }
        return false;
    }

    int pieceValue(char p){
        switch(Character.toLowerCase(p)){case 'q':return 9;case 'r':return 5;case 'b':case 'n':return 3;case 'p':return 1;default:return 0;}
    }
}
