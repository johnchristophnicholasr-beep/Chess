# Chess — fixed Android project

This version fixes the GitHub Actions error shown in the screenshot.

## Important
The old workflow searched for `settings.gradle` anywhere and then tried to build a project that was not a valid Android Gradle project. This ZIP has a real Android project at the repository root:

- `settings.gradle`
- `build.gradle`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/.../MainActivity.java`
- `app/src/main/assets/index.html`
- `.github/workflows/build.yml`

The workflow uses Gradle 8.9 + Java 17 and builds `app-debug.apk`.

## GitHub phone steps
1. Create/open a GitHub repository.
2. Upload **everything inside this ZIP** to the repository root.
3. Open **Actions**.
4. Choose **Build Chess APK**.
5. Tap **Run workflow**.
6. Open the completed run and download the **Chess-debug-apk** artifact.

Do not upload the ZIP file *inside* the repository expecting Actions to unpack it. Upload the files/folders themselves.

## Included prototype features
- Playable local chess board with legal movement, check/checkmate and basic castling/en-passant/promotion.
- Easy/Normal/Hard/Impossible AI buttons (prototype AI strength).
- Beginner tutorial Lv.1–10.
- Custom lobby UI, 10 player slots, room codes and team selection.
- Global/Lobby/Team chat UI.
- Player profile, XP/levels, achievements, stats, rating UI.
- Android microphone permission, voice recognition bridge and natural Android Text-to-Speech.
- GitHub Actions APK build.

Real internet matchmaking/global chat requires a backend service; this project currently provides the UI/local prototype rather than a production online server.
